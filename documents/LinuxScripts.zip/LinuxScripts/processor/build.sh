python process.py
cp *.h ../emulator/cpu
