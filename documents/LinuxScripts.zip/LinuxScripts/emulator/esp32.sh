sh build/prebuild.sh
pushd ../esp32
sh build.sh
popd




